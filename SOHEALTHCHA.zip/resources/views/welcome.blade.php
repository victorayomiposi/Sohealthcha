<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Get Candidate Registration Pin</title>
    <link href="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/css/bootstrap.min.css" rel="stylesheet">
    <link href="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/css/toastr.css" rel="stylesheet" />
    <style>
        body {
            height: 100vh;
            display: flex;
            justify-content: center;
            align-items: center;
            background-color: #f0f0f0;
        }

        /* body {
            background-image: url({{ asset('images/ondo-bg.jpeg') }});
            background-size: cover;
            background-opacity: 0.8;
        } */

        .card {
            box-shadow: 0 0 10px rgba(10, 153, 255, 0.719);
        }
    </style>
</head>

<body>
    <div class="card text-center" style="border-radius: 10px">
        <div class="card-body">
            <h5 class="card-title text-danger" style="font-weight: 800">Get Candidate Registration Pin</h5>
            <div class="card-body">
                <form action="{{ route('payment.store') }}" method="post">
                    @csrf
                    <div class="row">
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="form-label">Email:</label>
                                <input name="email" type="email" class="form-control"
                                    placeholder="Enter Your Active Gmail">
                            </div>
                        </div>
                        <div class="col-sm-6">
                            <div class="form-group">
                                <label class="form-label">Pin Amount:</label>
                                <select id="pincount" name="count" class="form-control">
                                    <option value="">Select Pin Amount</option>
                                    <option value="1">1</option>
                                    <option value="2">2</option>
                                    <option value="3">3</option>
                                    <option value="4">4</option>
                                    <option value="5">5</option>
                                    <option value="6">6</option>
                                    <option value="7">7</option>
                                    <option value="8">8</option>
                                    <option value="9">9</option>
                                    <option value="10">10</option>
                                </select>
                            </div>
                        </div>
                        <div class="col-sm-12">
                            <div class="form-group">
                                <button id="pinamount" type="button" class="col-sm-12 btn btn-success text-white p-2" style="font-weight: 800">
                                   </button>
                            </div>
                        </div>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <script src="https://code.jquery.com/jquery-3.5.1.min.js"></script>
    <script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.5.4/dist/umd/popper.min.js"></script>
    <script src="https://stackpath.bootstrapcdn.com/bootstrap/4.5.2/js/bootstrap.min.js"></script>
    <script src="https://cdnjs.cloudflare.com/ajax/libs/toastr.js/2.0.1/js/toastr.js"></script>
    <script>
        $(document).ready(function() {
            toastr.options.timeOut = 10000;
            @if (Session::has('error'))
                toastr.warning('{{ Session::get('error') }}');
            @elseif (Session::has('success'))
                toastr.success('{{ Session::get('success') }}');
            @elseif (Session::has('successlogin'))
                toastr.info('{{ Session::get('successlogin') }}');
            @endif
        });
    </script>
    @if ($errors->any())
        <script>
            toastr.options.timeOut = 10000;
            @foreach ($errors->all() as $error)
                toastr.danger('{{ $error }}');
            @endforeach
        </script>
    @endif
    <script>
        $(document).ready(function() {
            $('#pincount').change(function() {
                var pinCount = $(this).val();
                var pinAmount = pinCount * 10000;

                if (pinCount === null || pinCount === '' || pinCount == 0) {
                    $('#pinamount').attr('type', 'button').text('Select Amount');
                } else {
                    $('#pinamount').attr('type', 'submit').text('PAY' + ' ' + '₦' + pinAmount);
                }
            });
        });
    </script>

</body>

</html>
