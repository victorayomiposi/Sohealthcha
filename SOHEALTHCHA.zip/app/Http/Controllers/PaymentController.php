<?php

namespace App\Http\Controllers;

use App\Models\Customer;
use App\Models\Payment;
use Carbon\Carbon;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Http;
use Illuminate\Http\Client\RequestException;

class PaymentController extends Controller
{

    public function index()
    {
    }


    public function create(Request $request)
    {
        try {
            $request->validate([
                'count' => 'required|min:1|max:10',
                'email' => 'required|email',
            ]);

            $apiKey = '0PUB0535v5Pv2Yte0eVK1no180Q5F53C';
            $url = 'https://api.credodemo.com/transaction/initialize';
            $count = $request->count;
            $countamount = $count * 10000;
            $amount = $countamount * 100;
            $requestData = [
                'email' => $request->email,
                'amount' => $amount,
                'api-public-key' => $apiKey,
                'callbackUrl' => 'http://localhost:8000/payments/callback',
            ];

            $response = Http::withHeaders([
                'Authorization' => $apiKey,
                'Content-Type' => 'application/json',
            ])->post($url, $requestData);

            $statusCode = $response->status();
            $responseData = $response->json();
            $errorResponse = $response->body();
            $message = $responseData['message'];
            if ($statusCode === 200) {
                $authorizationUrl = $responseData['data']['authorizationUrl'];
                $candidatesave = Customer::create([
                    'email' => $request->email,
                    'amount' => $amount,
                    'count' => $count,
                    'time' => now(),
                    'status' => 0,
                    'authorizationUrl' => $authorizationUrl,
                    'reference' => $responseData['data']['reference'],
                    'credoReference' => $responseData['data']['credoReference'],
                ]);
                return view('open-new-tab', ['authorizationUrl' => $authorizationUrl]);
            } else {
                return back()->withErrors(['error' => "Error $statusCode: $message"]);
            }
        } catch (RequestException $e) {
            return back()->withErrors(['error' => 'Could not connect to the server. Please check your internet connection.']);
        }
    }

    public function callback(Request $request)
    {

        $status = $request->query('status');
        $errorMessage = $request->query('errorMessage');
        $transRef = $request->query('transRef');
        $transAmount = $request->query('transAmount');
        $currency = $request->query('currency');
        $reference = $request->query('reference');

        $transactionStatus = $this->verifyTransaction($transRef);
    }


    public function verifyTransaction($transRef)
    {

        try {
            $apiKey = '0PRI0535pD2xv3MCsDd6bFj1Ih7MQcP7';
            $verifyUrl = "https://api.credodemo.com/transaction/{$transRef}/verify";
            $requestData = [
                'api-secret-key' => $apiKey,
                'transRef' => $transRef,
            ];
            $response = Http::withHeaders([
                'Authorization' =>  $apiKey,
                'Content-Type' => 'application/json',
            ])->get($verifyUrl, $requestData);
            dd($response, $requestData);

            $statusCode = $response->status();
            $responseData = $response->json();

            if ($statusCode === 200) {
                $transactionStatus = $responseData['data']['status'];
                return $transactionStatus;
            } else {
                $errorMessage = $responseData['error'];
                return "Error $statusCode: $errorMessage";
            }
        } catch (RequestException $e) {
            return 'Could not connect to the server. Please check your internet connection.';
        }
    }
}
