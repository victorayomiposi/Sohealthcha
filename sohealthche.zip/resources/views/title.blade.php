<title>ONDO STATE COLLEGE OF HEALTH TECHNOLOGY AKURE</title>
<link rel="icon" type="image/png" sizes="16x16" href="{{ asset('assets/images/favicon.png') }}">
<link rel="shortcut icon" type="image/x-icon" sizes="16x16" href="{{ asset('assets/images/favicon.png') }}">
 	