<footer class="main-footer no-print">
    <strong>Copyright &copy; <i id="year"></i> <a href="#">SOHEALTHCHA</a>.</strong>
    All rights reserved.
    <div class="float-right d-none d-sm-inline-block">

    </div>
</footer>