<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Login Page</title>
    <style>
        body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            background-color: #f0f0f0;
        }

        .container {
            display: flex;
            justify-content: center;
            align-items: center;
            position: absolute;
            width: 100%;
            height: 100%;
        }

        .card {
            padding: 20px;
            border-radius: 5px;
            box-shadow: 0 2px 6px rgba(0, 0, 0, 0.2);
            background-color: #ffffff;
            max-width: 400px;
            width: 100%;
        }

        h2 {
            text-align: center;
        }

        form {
            display: flex;
            flex-direction: column;
        }

        label {
            margin-top: 10px;
        }

        input {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-top: 5px;
        }
        select {
            padding: 10px;
            border: 1px solid #ccc;
            border-radius: 3px;
            margin-top: 5px;
        }

        button {
            margin-top: 20px;
            padding: 10px;
            background-color: #007bff;
            color: #ffffff;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        button:hover {
            background-color: #0056b3;
        }
        a {
           text-align: center;
            margin-top: 10px;
            padding: 10px;
            background-color: #ffc107;
             color: #212529;
            border: none;
            border-radius: 3px;
            cursor: pointer;
        }

        a:hover {
            background-color: #ffc107;
        }
    </style>
</head>

<body>
    <div class="container">
         <div class="card">
            <h2>UPDATE CUT OFF MARK </h2>
            <form action="{{ route('cut-off.update', $cutoff->id) }}" method="POST">
                @csrf
                @method('PUT')
                 <select disabled name="department" required>
                    <option value=""> --{{ $cutoff->name }}-- </option> </select>
                <label for="username">Department:</label>
                <select name="department" required>
                    <option value=""> --Select Department-- </option>
                    @foreach ($course as $course)
                        <option value="{{ $course->coursename }}">{{ $course->coursename }}</option>
                    @endforeach
                </select>
                <label for="">TYPE:</label>
                <select name="type">
                <option value=""> --Select Type-- </option>
                <option value="1">Indigene</option>
                <option value="0">Non-Indigene</option>
                </select>
                <label for="">CUT OFF MARK:</label>
                <input required name="cutoffmark" type="number" value="{{ $cutoff->cut_off }}">
                <button type="submit">Update</button>
                <a href="{{ route('cutoffmark_depart') }}">Back</a>
            </form>
        </div>
    </div>
</body>

</html>
