<?php

use App\Http\Controllers\Auth\AuthenticatedSessionController;
use App\Http\Controllers\Auth\ConfirmablePasswordController;
use App\Http\Controllers\Auth\EmailVerificationNotificationController;
use App\Http\Controllers\Auth\EmailVerificationPromptController;
use App\Http\Controllers\Auth\NewPasswordController;
use App\Http\Controllers\Auth\PasswordController;
use App\Http\Controllers\Auth\PasswordResetLinkController;
use App\Http\Controllers\admin\RegisteredUserController;
use App\Http\Controllers\Auth\VerifyEmailController;
use App\Http\Controllers\Admin\user\UserController;
use App\Http\Controllers\Admin\user\AgentController;
use App\Http\Controllers\candidate\ExamController;
use App\Http\Controllers\Admin\exam\ActionController;
use App\Http\Controllers\Admin\exam\AllocationController;
use App\Http\Controllers\blog\CourseblogController;
use App\Http\Controllers\candidate\ViewCandController;
use App\Http\Controllers\candidate\AdmissionController;
use App\Http\Controllers\department\DepartmentController;
use App\Http\Controllers\pin\PinController;
use App\Http\Controllers\candidate\AcceptanceController;
use Illuminate\Support\Facades\Route;
use App\Http\Controllers\blog\DepartblogController;
use App\Http\Controllers\blog\EventController;
use App\Http\Controllers\candidate\UploadresultController;

Route::middleware('guest')->group(function () {
    Route::get('register', [RegisteredUserController::class, 'create'])
                ->name('register');

    Route::post('register', [RegisteredUserController::class, 'store']);

    Route::get('login', [AuthenticatedSessionController::class, 'create'])
                ->name('login');

    Route::post('login', [AuthenticatedSessionController::class, 'store']);

    Route::get('forgot-password', [PasswordResetLinkController::class, 'create'])
                ->name('password.request');

    Route::post('forgot-password', [PasswordResetLinkController::class, 'store'])
                ->name('password.email');

    Route::get('reset-password/{token}', [NewPasswordController::class, 'create'])
                ->name('password.reset');

    Route::post('reset-password', [NewPasswordController::class, 'store'])
                ->name('password.store');
});

Route::middleware('auth')->group(function () {
    Route::get('verify-email', EmailVerificationPromptController::class)
                ->name('verification.notice');

    Route::get('verify-email/{id}/{hash}', VerifyEmailController::class)
                ->middleware(['signed', 'throttle:6,1'])
                ->name('verification.verify');

    Route::post('email/verification-notification', [EmailVerificationNotificationController::class, 'store'])
                ->middleware('throttle:6,1')
                ->name('verification.send');

    Route::get('confirm-password', [ConfirmablePasswordController::class, 'show'])
                ->name('password.confirm');

    Route::post('confirm-password', [ConfirmablePasswordController::class, 'store']);

    Route::put('password', [PasswordController::class, 'update'])->name('password.update');

    Route::get('logout', [AuthenticatedSessionController::class, 'destroy'])
                ->name('logout');
});

 
Route::group([
    'prefix' => 'panel',
    'middleware' => ['auth'],
], function () {
    /*........................USER ROUTE...........................*/
    Route::get('/admin/user/create', [UserController::class, 'create'])->name('add_user');
    Route::get('/admin/user/view', [UserController::class, 'view'])->name('view_user');
    Route::get('/admin/user/edit/{id}', [UserController::class, 'edit'])->name('edit_user');
    Route::get('/admin/user/delete/{id}', [UserController::class, 'delete'])->name('delete_user');
    Route::get('/admin/user/permission', [UserController::class, 'permission'])->name('permission_user');
    Route::get('/admin/user/permission/{id}', [UserController::class, 'permission_edit'])->name('edit_permission');

    /*........................AGENT ROUTE...........................*/
    Route::get('/admin/agent/create', [AgentController::class, 'create'])->name('add_agent');
    Route::get('/admin/agent/view', [AgentController::class, 'view'])->name('view_agent');
    Route::get('/admin/agent/edit/{id}', [AgentController::class, 'edit'])->name('edit_agent');
    Route::get('/admin/agent/delete/{id}', [AgentController::class, 'delete'])->name('delete_agent');
     
    /*........................PIN ROUTE...........................*/
    Route::get('/admin/candidate/pin/generate', [PinController::class, 'index'])->name('add_pin');
    Route::get('/admin/course/pin/generate', [PinController::class, 'course'])->name('course_pin');
    Route::get('/admin/candidate/pin/print/{per_page}/{usepin}', [PinController::class, 'printcandidatepin'])->name('candidate.pin.print');
    Route::get('/admin/admission/pin/generate', [PinController::class, 'admission'])->name('admission_pin');
    Route::get('/admin/candidate/pin/delete/{id}', [AgentController::class, 'destroy'])->name('pins.destroy');
    Route::get('/admin/change/course/delete/{id}', [AgentController::class, 'delete_course_pin'])
    ->name('coursepins.destroy');
      Route::get('/admin/admission/delete/{pinid}', [AgentController::class, 'delete_admission_pin'])
    ->name('admission.destroy');

    /*........................EXAM ROUTE...........................*/
    Route::get('/admin/set/exam/date', [ExamController::class, 'set_exam_date'])->name('exam_date');
    Route::get('/admin/exam/allocation', [AllocationController::class, 'index'])->name('exam_allocate');
    Route::get('/admin/exam/allocation/download', [AllocationController::class, 'export_candidates'])->name('export_candidates_list');
    Route::get('/admin/exam/allocation/view', [AllocationController::class, 'view'])->name('view_allocate');
    Route::get('allocation/batch/edit/{id}', [ActionController::class, 'edit_batch'])->name('edit.batch');
    Route::get('allocation/batch/delete/{id}', [ActionController::class, 'destroy_batch'])->name('delete.batch');
    Route::get('allocation/time/edit/{id}', [ActionController::class, 'edit_time'])->name('edit.time');
    Route::get('allocation/time/delete/{id}', [ActionController::class, 'destroy_time'])->name('delete.time');

    /*........................APPLICANT ROUTE...........................*/
    Route::get('/admin/applicant/view', [ViewCandController::class, 'index'])->name('view_applicant');
    Route::get('/admin/photocard/{id}', [ViewCandController::class, 'show']);
    Route::get('/admin/applicant/olevel', [ViewCandController::class, 'olevel'])->name('olevel_status');
    Route::get('/admin/view/course', [ViewCandController::class, 'course_list'])->name('applicantcourse');
    Route::get('/admin/edit/course/{id}', [ViewCandController::class, 'edit_course']);
    Route::get('/applicant/result/upload', [UploadresultController::class, 'result_upload'])->name('resultupload');
    Route::get('/applicant/result/view', [UploadresultController::class, 'index'])->name('resultview');
    Route::get('/applicant/passort/export', [UploadresultController::class, 'passort'])->name('exortpassort');
    Route::get('/applicant/data/export', [ViewCandController::class, 'exportInfo'])->name('exportdetails');
    Route::get('/admin/acceptanceletter/{admissionnumber}', [AcceptanceController::class, 'show'])->name('admin.acceptanceletter');

    /*........................ADMISSION ROUTE...........................*/
    Route::get('/admin/admission/upload', [AdmissionController::class, 'create'])->name('admission_upload');
    Route::get('/admin/admission/view', [AdmissionController::class, 'index'])->name('admission_view');
    Route::get('/admin/admission/lock', [AdmissionController::class, 'lock'])->name('admission_lock');
    Route::get('/admin/admission/export', [AdmissionController::class, 'export'])->name('admission_export');

    /*........................DEPARTMENT ROUTE...........................*/
    Route::get('/admin/department/create', [DepartmentController::class, 'create'])->name('add_department');
    Route::get('/admin/department/view', [DepartmentController::class, 'index'])->name('view_department');
    Route::get('/admin/department/edit/{id}', [DepartmentController::class, 'edit'])->name('edit_department');
    Route::get('/admin/department/delete/{id}', [DepartmentController::class, 'destroy'])->name('delete_department');
    Route::get('/admin/programme/create', [DepartmentController::class, 'programme'])->name('add_programme');
    Route::get('/admin/configure/cut_off_mark', [DepartmentController::class, 'cutoffmark'])->name('cutoffmark_depart');
    Route::get('/admin/cutoff/delete/{id}', [DepartmentController::class, 'cutoffmark_delete'])->name('cutoff_delete');
    Route::get('/admin/cutoff/edit/{id}', [DepartmentController::class, 'cutoffmark_edit'])->name('cutoff_edit');

/*..................................................BLOG ROUTE.................................................*/
Route::get('/admin/department/blog/create', [DepartblogController::class, 'create'])->name('depart_blog_add');
Route::get('/admin/department/blog/view', [DepartblogController::class, 'index'])->name('depart_blog');
Route::get('/admin/department/blog/edit/{id}', [DepartblogController::class, 'edit'])->name('depart_blog_edit');
Route::get('/admin/department/blog/delete/{id}', [DepartblogController::class, 'destroy'])->name('depart_blog_delete');
Route::get('/department/blog/show/{id}', [DepartblogController::class, 'show'])->name('depart_blog_show');
Route::get('/admin/department/content/create', [DepartblogController::class, 'blog'])->name('departbloger');
Route::get('/admin/department/content/view', [DepartblogController::class, 'content'])->name('deptblogview');

Route::get('/admin/course/blog/create', [CourseblogController::class, 'create'])->name('course_blog_add');
Route::get('/admin/course/blog/view', [CourseblogController::class, 'index'])->name('course_blog');
Route::get('/admin/course/blog/edit/{id}', [CourseblogController::class, 'edit'])->name('course_blog_edit');
Route::get('/admin/course/blog/delete/{id}', [CourseblogController::class, 'destroy'])->name('course_blog_delete');
Route::get('/course/blog/show/{id}', [CourseblogController::class, 'show'])->name('course_blog_show');
Route::get('/admin/course/content/create', [CourseblogController::class, 'blog'])->name('coursebloger');
Route::get('/admin/course/content/view', [CourseblogController::class, 'content'])->name('courseblogview');

Route::get('/admin/event/blog/create', [EventController::class, 'create'])->name('event_blog');
Route::get('/admin/event/blog/view', [EventController::class, 'index'])->name('view_event');

});
