<?php

namespace App\Exports\candidate;

use Illuminate\Support\Facades\DB;
use Maatwebsite\Excel\Concerns\FromCollection;
use Maatwebsite\Excel\Concerns\WithEvents;
use Maatwebsite\Excel\Concerns\WithHeadings;
use Maatwebsite\Excel\Events\AfterSheet;

class ApplicantTemplateExport implements FromCollection, WithHeadings, WithEvents
{
    public function collection()
    {
        // Return an empty collection to create an empty template
        return collect([]);
    }

    public function headings(): array
    {
        return [
            'admissionnumber',
            'score',
        ];
    }

    public function registerEvents(): array
    {
        return [
            AfterSheet::class => function (AfterSheet $event) {
                $highestColumn = $event->sheet->getHighestColumn();
                $highestRow = $event->sheet->getHighestRow();

                for ($row = 1; $row <= $highestRow; $row++) {
                    for ($col = 'A'; $col <= $highestColumn; $col++) {
                        $cell = $col . $row;
                        $event->sheet->getDelegate()->getStyle($cell)->applyFromArray([
                            'borders' => [
                                'outline' => [
                                    'borderStyle' => \PhpOffice\PhpSpreadsheet\Style\Border::BORDER_THIN,
                                    'color' => ['rgb' => '000000'],
                                ],
                            ],
                            'padding' => [
                                'top' => 5,
                                'right' => 5,
                                'bottom' => 5,
                                'left' => 5,
                            ],
                        ]);
                    }
                }
            },
        ];
    }
}
