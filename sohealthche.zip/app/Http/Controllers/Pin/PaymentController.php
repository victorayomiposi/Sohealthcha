<?php

namespace App\Http\Controllers\Pin;

use App\Http\Controllers\Controller;
use Illuminate\Http\Request;

class PaymentController extends Controller
{
    //
}
